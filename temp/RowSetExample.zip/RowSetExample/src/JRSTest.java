
import javax.sql.rowset.*;
import javax.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.*;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ProvenSoft
 */
public class JRSTest {

    private Properties settings;
    private JoinRowSet catprod;

    public static void main(String[] args) {
        JRSTest main = new JRSTest();
        main.start();
    }

    public void start() {
        settings = new Properties();
        settings.setProperty("url", "jdbc:mysql://127.0.0.1/storedb");
        settings.setProperty("username", "storeusr");
        settings.setProperty("password", "storepsw");
        try {
            //create a new rowset
            catprod = buildJoinRowSet(settings);
            //add a listener
//            catprod.addRowSetListener(new RSListener());
            //show the rowset
            showRowSet(catprod);
            //modify something in rowset
            makeChanges(catprod);
        } catch (SQLException ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
        }
    }

    public JoinRowSet buildJoinRowSet(Properties settings) throws SQLException {
        JoinRowSet result;
        //
        RowSetFactory factory = RowSetProvider.newFactory();
        CachedRowSet crs1 = factory.createCachedRowSet();
        CachedRowSet crs2 = factory.createCachedRowSet();
        JoinRowSet jrs = factory.createJoinRowSet();
        //
        crs1.setCommand("select * from categories");
        crs1.setUsername(settings.getProperty("username"));
        crs1.setPassword(settings.getProperty("password"));
        crs1.setUrl(settings.getProperty("url"));
        crs1.execute();
        //
        crs2.setCommand("select * from products");
        crs2.setUsername(settings.getProperty("username"));
        crs2.setPassword(settings.getProperty("password"));
        crs2.setUrl(settings.getProperty("url"));
        crs2.execute();
//        //
        jrs.clearParameters();
        jrs.setUsername(settings.getProperty("username"));
        jrs.setPassword(settings.getProperty("password"));
        jrs.setUrl(settings.getProperty("url"));
//        //
        jrs.addRowSet(crs1, "id");
        jrs.addRowSet(crs2, "category_id");
        System.out.println("Table names: " + Arrays.asList(jrs.getRowSetNames()));
        //
        result = jrs;
//        result = crs1;
        return result;
    }

    public void makeChanges(JoinRowSet rs) throws SQLException {
        rs.absolute(3);
        showRowSetRow(rs);
/*
        rs.updateString(3, "category01");
        rs.updateString(6, "category01");
        rs.updateRow();
        rs.acceptChanges(getConnection(settings, false));
        //rs.acceptChanges();
*/

        List crsList = rs.getRowSets().stream().toList();
        CachedRowSet rs1 = (CachedRowSet) crsList.get(0);
        showRowSetRow(rs1);
        rs1.updateString(3, "category_ch");
        rs1.updateRow();
        rs1.acceptChanges(getConnection(settings, false));
        CachedRowSet rs2 = (CachedRowSet) crsList.get(1);
        showRowSetRow(rs2);
        rs2.updateString(3, "product_ch");
        rs2.updateRow();
        rs2.acceptChanges(getConnection(settings, false));     
        //rs.execute();

    }

    public Connection getConnection(Properties settings, boolean autocommit) throws SQLException {
        System.out.println("Settings: " + settings);
        Connection conn = DriverManager.getConnection(
                settings.getProperty("url"),
                settings.getProperty("username"),
                settings.getProperty("password"));
        conn.setAutoCommit(autocommit);
        return conn;
    }

    public boolean commitToDatabase(JoinRowSet rs, Properties settings) {
        boolean b;
        try ( Connection conn = getConnection(settings, false)) {
            // propagate changes and close connection
            rs.acceptChanges(conn);
            // reload data.
            rs.execute();
            b = true;
        } catch (SQLException se) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, se);
            b = false;
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, e);
            b = false;
        }
        return b;
    }

    public void showRowSet(CachedRowSet rs) throws SQLException {
        //write to xml
//        try {
//            ((JoinRowSet)rs).writeXml(System.out);
//        } catch (IOException ex) {
//            Logger.getLogger(JRSTest.class.getName()).log(Level.SEVERE, null, ex);
//        }
        //get metadata
        rs.beforeFirst();
        RowSetMetaData rsmd = (RowSetMetaData) rs.getMetaData();
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= rsmd.getColumnCount(); i++) {
            sb.append("(").append(rsmd.getColumnName(i)).append(")");
        }
        System.out.println(sb.toString());
        //get data
        sb = new StringBuilder();
        while (rs.next()) {
            sb.append("[");
            for (int i = 0; i < rsmd.getColumnCount(); i++) {
                sb.append("(").append(rs.getObject(i + 1)).append(")");
            }
            sb.append("]\n");
        }
        rs.beforeFirst();
        System.out.println(sb.toString());
        //System.out.println("WhereClause: "+((JoinRowSet)rs).getWhereClause());
    }

    public void showRowSetRow(CachedRowSet rs) throws SQLException {
        StringBuilder sb = new StringBuilder();
        RowSetMetaData rsmd = (RowSetMetaData) rs.getMetaData();
        sb.append("[");
        for (int i = 0; i < rsmd.getColumnCount(); i++) {
            sb.append("(").append(rs.getObject(i + 1)).append(")");
        }
        sb.append("]\n");
        System.out.println(sb.toString());
    }
}

class RSListener implements RowSetListener {

    public static int rowSetChangedCounter = 0;
    public static int rowChangedCounter = 0;
    public static int cursorMovedCounter = 0;

    @Override
    public void rowSetChanged(RowSetEvent rse) {
        rowSetChangedCounter++;
        System.out.println(this.toString());
    }

    @Override
    public void rowChanged(RowSetEvent rse) {
        rowChangedCounter++;
        System.out.println(this.toString());
    }

    @Override
    public void cursorMoved(RowSetEvent rse) {
        cursorMovedCounter++;
        System.out.println(this.toString());
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("RSListener{");
        sb.append("rowSetChangedCounter:").append(rowSetChangedCounter);
        sb.append(";rowChangedCounter:").append(rowChangedCounter);
        sb.append(";cursorMovedCounter:").append(cursorMovedCounter);
        sb.append('}');
        return sb.toString();
    }

}
