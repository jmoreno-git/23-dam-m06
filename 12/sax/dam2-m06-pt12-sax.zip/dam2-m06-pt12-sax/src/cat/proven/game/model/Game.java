package cat.proven.game.model;

/**
 * ADT class for a game
 * @author ProvenSoft
 */
public class Game {
    // TODO
}
