package cat.proven.game.model;

/**
 * ADT for a player
 * @author ProvenSoft
 */
public class Players {
    //TODO
}
