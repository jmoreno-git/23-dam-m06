
package cat.proven.game.model.persist;

import cat.proven.game.model.Game;

/**
 * SAX XML file reader for game.
 * @author ProvenSoft
 */
public class XmlSaxGame {
    
    /**
     * loads game data from xml file given the game id.
     * @param gameId the id of the game to retrieve
     * @return TODO 
     */
     public Game load(String gameId) {
         Game data = null;
         //TODO
         return data;
     }
     
}
